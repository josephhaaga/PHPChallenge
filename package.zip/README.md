This is a PHP coding challenge
