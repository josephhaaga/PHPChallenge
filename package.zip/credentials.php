<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "php_challenge";
